//
// Copyright 2020 The ANGLE Project Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//
// Platform.h: Simple forwarding header to PlatformMethods.h.
// Ideally we can remove this file at some point since "Platform.h" is overloaded.
//

#include "PlatformMethods.h"
